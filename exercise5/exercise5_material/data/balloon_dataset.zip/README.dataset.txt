# balloon_detection > 2022-08-23 3:06pm
https://universe.roboflow.com/object-detection/balloon_detection

Provided by Roboflow
License: CC BY 4.0

